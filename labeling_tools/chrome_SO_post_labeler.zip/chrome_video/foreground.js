console.log("I'm inside google.")
var index = 0
var body = document.body
var control_key = false

body.addEventListener('mousemove', e => {
    
});

function highlightSelection() {
    var userSelection = window.getSelection().getRangeAt(0);
    var safeRanges = getSafeRanges(userSelection);
    for (var i = 0; i < safeRanges.length; i++) {
        highlightRange(safeRanges[i]);
    }
}

function highlightRange(range, tag) {
    var newNode = document.createElement("div");
    newNode.setAttribute(
       "style",
       "display: inline;"
    );
    newNode.setAttribute("class", tag)
    // newNode.classList.add("selected")
    range.surroundContents(newNode);
}

function getSafeRanges(dangerous) {
    var a = dangerous.commonAncestorContainer;
    var s = new Array(0), rs = new Array(0);
    if (dangerous.startContainer != a)
        for(var i = dangerous.startContainer; i != a; i = i.parentNode)
            s.push(i);
    if (0 < s.length) for(var i = 0; i < s.length; i++) {
        var xs = document.createRange();
        if (i) {
            xs.setStartAfter(s[i-1]);
            xs.setEndAfter(s[i].lastChild);
        }
        else {
            xs.setStart(s[i], dangerous.startOffset);
            xs.setEndAfter(
                (s[i].nodeType == Node.TEXT_NODE)
                ? s[i] : s[i].lastChild
            );
        }
        rs.push(xs);
    }

    var e = new Array(0), re = new Array(0);
    if (dangerous.endContainer != a)
        for(var i = dangerous.endContainer; i != a; i = i.parentNode)
            e.push(i)
    ;
    if (0 < e.length) for(var i = 0; i < e.length; i++) {
        var xe = document.createRange();
        if (i) {
            xe.setStartBefore(e[i].firstChild);
            xe.setEndBefore(e[i-1]);
        }
        else {
            xe.setStartBefore(
                (e[i].nodeType == Node.TEXT_NODE)
                ? e[i] : e[i].firstChild
            );
            xe.setEnd(e[i], dangerous.endOffset);
        }
        re.unshift(xe);
    }

    // Middle -- the uncaptured middle
    if ((0 < s.length) && (0 < e.length)) {
        var xm = document.createRange();
        xm.setStartAfter(s[s.length - 1]);
        xm.setEndBefore(e[e.length - 1]);
    }
    else {
        return [dangerous];
    }

    // Concat
    rs.push(xm);
    response = rs.concat(re);    

    // Send to Console
    return response;
}


function getHTMLOfSelection () {
    var range;
    if (document.selection && document.selection.createRange) {
        range = document.selection.createRange();
        return range.htmlText;
    }
    else if (window.getSelection) {
        var selection = window.getSelection();
        if (selection.rangeCount > 0) {
            range = selection.getRangeAt(0);
            var clonedSelection = range.cloneContents();
            var div = document.createElement('div');
            div.appendChild(clonedSelection);
            return div.innerHTML;
        }
        else {
        return '';
        }
    }
    else {
        return '';
    }
}

function prepare_to_label() {
    clean_selected()
    var text = getHTMLOfSelection()
    if (window.getSelection() && text != "") {
        console.log("Selected text")
        var prev_html = window.getSelection().anchorNode.parentNode.innerHTML
        var selection = window.getSelection();
        if (selection.rangeCount > 0) {
            var prev_parent = window.getSelection().anchorNode.parentNode.innerHTML
            var userSelection = window.getSelection().getRangeAt(0);
            var safeRanges = getSafeRanges(userSelection);
            for (var i = 0; i < safeRanges.length; i++) {
                highlightRange(safeRanges[i], "selected");
            }
        }
    }
}

chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
      if (request.greeting === "prepare_to_label") {
        console.log("Let's prepare to label!!")
        sendResponse({farewell: "preparing to label"});
        prepare_to_label()
      }
    }
  );


function clean_selected() {
    var elements = document.querySelectorAll(".selected");
    console.log(elements)
    for (var i = 0; i < elements.length; i++) {
        console.log(elements[i])
        elements[i].classList.remove("selected");
        console.log(elements[i])
    }
}

function clean_screen() {
    var elements = document.querySelectorAll(".selected, .labeled");
    console.log(elements)
    for (var i = 0; i < elements.length; i++) {
        console.log(elements[i])
        if (elements[i].classList.contains("selected")) {
            elements[i].classList.remove("selected");
        }
        if (elements[i].classList.contains("labeled")) {
            elements[i].classList.remove("labeled");
        }
        console.log(elements[i])
    }
}

chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        if (request.greeting === "label_it") {
        console.log("Summary!")
        sendResponse({farewell: "labeled it"});
        label_it()
    }
    }
);


function label_it(){
    var text = getHTMLOfSelection()
    if (window.getSelection() && text != "") {
        console.log("Selected text")
        var prev_html = window.getSelection().anchorNode.parentNode.innerHTML
        var selection = window.getSelection();
        if (selection.rangeCount > 0) {
            var prev_parent = window.getSelection().anchorNode.parentNode.innerHTML
            var userSelection = window.getSelection().getRangeAt(0);
            var safeRanges = getSafeRanges(userSelection);
            for (var i = 0; i < safeRanges.length; i++) {
                highlightRange(safeRanges[i], "labeled");
            }
            index += 1
            console.log(index)
        }
    }
}


document.onkeydown = function(e) {
    console.log(e)
    // alert('test')
    if (e["key"] == "Escape") {
        console.log("Get out of here.")
        clean_screen()
    }

    if (e["key"] == "Enter" && control_key) {
        send_selection()
    }

    if (e["key"] == "Control") {
        console.log("Control down")
        control_key = true
    }
};


document.onkeyup = function(e) {
    console.log(e)
    // alert('test')
    if (e["key"] == "Control") {
        console.log("Control up")
        control_key = false
    }
};

function check_individual(varlist) {
    var result = Array(0)
    var add = true
    for (var i = 0; i < varlist.length; i++) {
        add = true
        for (var j = 0; j < varlist.length; j++) {
            if (i != j) {
                parent = varlist[j]
                child = varlist[i]
                if (parent !== child && parent.contains(child)) {
                    add = false
                }
            }
        }
        if (add) {
            result.push(varlist[i])
        }
    }
    return result
}
function send_selection() {
    var corpus = document.querySelectorAll(".selected");
    corpus = check_individual(corpus)
    var selected_corpus = ""
    console.log(corpus)
    for (var i = 0; i < corpus.length; i++) {
        selected_corpus += corpus[i].innerText
        console.log(corpus[i].innerText)
    }

    var labels = document.querySelectorAll(".labeled");
    labels = check_individual(labels)
    console.log(labels)
    var labeled_text = ""
    for (var i = 0; i < labels.length; i++) {
        labeled_text += labels[i].innerText
        console.log(labels[i].innerText)
    }

    chrome.runtime.sendMessage(
        selected_corpus + "longlivebonankou" + labeled_text
    )
    selected_corpus = `This can still happen in newer versions of Visual Studio (I just had it happen on Visual Studio 2013):

    Another thing to try is to close Visual Studio and delete the .suo file that is next to the .sln file. (It will be re-generated the next time you Save all (or exit Visual Studio)).
    
    I've had this problem when adding new projects to the solution on another machine and then pulling the revisions in, but the .suo file can be corrupted in other cases as well and lead to very strange Visual Studio behaviour, so deleting it is one of the things I always try.
    
    Note that deleting the .suo file will reset the startup project(s) of the solution.
    
    More on the .suo file is here.`
    var temp = '[{"text":"' + selected_corpus + '","summary":"' + labeled_text + '"}]'
    // temp = escapeSpecialChars(temp)
    temp = escapeSpecialChars(temp)
    console.log(temp)
    download_csv(temp)
    // chrome.runtime.sendMessage({greeting: "gold"}, function(response) {
    //     console.log(response.farewell);
    //     download_csv()
    // });
}

// 总之先做视频
// 
function escapeSpecialChars(jsonString) {
    return jsonString.replace(/(\r\n|\n|\r)/gm, "")
            .replace(/\\n/g, "\\n")
            .replace(/\\'/g, "\\'")
            .replace(/\\"/g, '\\"')
            .replace(/\\&/g, "\\&")
            .replace(/\\r/g, "\\r")
            .replace(/\\t/g, "\\t")
            .replace(/\\b/g, "\\b")
            .replace(/\\f/g, "\\f");
}


function download_csv(text) {
    var json_pre = text;
    var json = JSON.parse(json_pre);
    console.log(json)
    var fields = Object.keys(json[0])
    var replacer = function(key, value) { return value === null ? '' : value } 
    var csv = json.map(function(row){
      return fields.map(function(fieldName){
        return JSON.stringify(row[fieldName], replacer)
      }).join(',')
    })
    csv.unshift(fields.join(',')) // add header column
    csv = csv.join('\r\n');

    var downloadLink = document.createElement("a");
    var blob = new Blob(["\ufeff", csv]);
    var url = URL.createObjectURL(blob);
    downloadLink.href = url;
    downloadLink.download = "data.csv";

    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
}

