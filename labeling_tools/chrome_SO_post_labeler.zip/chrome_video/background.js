urls = new Array(0)


// chrome.processes.onCreated.addListener(
//   console.log("Something here")
// )

var tabid = 0

processes = new Array(0)

chrome.webNavigation.onCommitted.addListener((details) => {
// chrome.processes.onCreated.addListener((details) => {
  // console.log(details.url)
  console.log(details)
  if (!processes.includes(details["processId"] + details["tabId"])) {
    chrome.tabs.get(details.tabId, current_tab_info => {
      tabid = details.tabId
      chrome.scripting.executeScript({files: ["./foreground.js"], target: {tabId: details.tabId}}, (result)=>{console.log("foreground.js complete")})
      chrome.scripting.insertCSS({files: ["./foreground.css"], target: {tabId: details.tabId}}, (result)=>{console.log("CSS complete")})
    })
    processes.push(details["processId"] + details["tabId"])
  }
});

chrome.contextMenus.create({
    title: "Select for label",
    id: "corpus",
    contexts:["page"]
  }
);

chrome.contextMenus.create({
  title: "Mark as Summative Sentence",
  id: "label",
  contexts:["selection"]
});

chrome.contextMenus.create({
  title: "Launch",
  id: "launch",
  contexts:["page_action", "browser_action", "action"]
});

chrome.contextMenus.onClicked.addListener(
  (data)=>{
    if (data["menuItemId"] == "corpus") {
      // Fire event
      // console.log("Sending, no hurry!")
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {greeting: "prepare_to_label"}, function(response) {
          console.log(response.farewell);
        });
      });
    }

    if (data["menuItemId"] == "label") {
      // Fire event
      // console.log("Sending, no hurry!")
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {greeting: "label_it"}, function(response) {
          console.log(response.farewell);
        });
      });
    }

    if (data["menuItemId"] == "launch") {
      console.log(data)
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.scripting.insertCSS({files: ["./video.css"], target: {tabId: tabid}}, (result)=>{console.log("Video CSS inserted.")})
      });
    }
  }
)

chrome.runtime.onMessage.addListener((data) => {
    console.log("妈妈，我变强了！")
    console.log(data)
  }
)



// chrome.contextMenus.create(
//   createProperties: object,
//   callback?: function,
// )

// Do some testing here
// chrome.runtime.onUpdateAvailable.addListener(tab => {
//   console.log("onUpdateAvailable", tab)
// })

// chrome.runtime.onSuspendCanceled.addListener(() => {
//   console.log("onSuspendCanceled")
// })

// chrome.runtime.onSuspend.addListener(() => {
//   console.log("onSuspend")
// })

// chrome.runtime.onStartup.addListener(() => {
//   console.log("onStartup")
// })

// chrome.runtime.onRestartRequired.addListener(reason => {
//   console.log("onRestartRequired", reason)
// })

// chrome.runtime.onMessageExternal.addListener((message, sender, sendresponse) => {
//   console.log("onMessageExternal", message)
// })

// chrome.runtime.onMessage.addListener((message, sender, sendresponse) => {
//   console.log("onMessage", message)
// })

// chrome.runtime.onInstalled.addListener(details => {
//   console.log("onInstalled", details.id)
// })

// chrome.runtime.onBrowserUpdateAvailable.addListener(() => {
//   console.log("onBrowserUpdateAvailable")
// })
